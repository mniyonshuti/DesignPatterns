package bank.commanpattern;

public interface Command {
    void execute();
    void unExecute();
}
