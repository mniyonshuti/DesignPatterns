package observerpattern;

public interface Observer {
    public void updateCount(int count);
}
