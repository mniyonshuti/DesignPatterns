package counter;

public interface Observer {
    public void updateCount(int count);
}
