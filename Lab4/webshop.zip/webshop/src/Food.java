public class Food extends Product {

}
