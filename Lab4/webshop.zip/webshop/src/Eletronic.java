public class Eletronic extends Product {
}
