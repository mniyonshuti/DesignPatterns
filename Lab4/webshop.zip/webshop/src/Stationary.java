public class Stationary extends Product {
}
