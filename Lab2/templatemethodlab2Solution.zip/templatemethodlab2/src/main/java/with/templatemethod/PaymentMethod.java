package with.templatemethod;

public interface PaymentMethod {
}
